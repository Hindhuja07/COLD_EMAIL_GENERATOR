
# AI Resume-Based Cold Email Generator

An AI-powered cold email generator that analyzes your resume and matches it with a job description to create personalized job application emails.

## 🚀 Features
- Upload PDF resume
- Resume text extraction
- Job description matching
- Personalized cold email drafting
- Fully local LLM (Ollama - mistral)

## 🛠 Tech Stack
- Python
- Streamlit
- Ollama (mistral)
- PyPDF2
- Prompt Engineering

## ▶️ How to Run

1. Install Ollama and pull model:
   ```
   ollama pull mistral
   ```

2. Start Ollama:
   ```
   ollama serve
   ```

3. Install dependencies:
   ```
   python -m pip install -r requirements.txt
   ```

4. Run the app:
   ```
   python -m streamlit run app.py
   ```

---

© 2026 Nithiyasri G
