import requests
import re
from PyPDF2 import PdfReader

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "mistral"


# ---------------- Extract Resume Text ----------------
def extract_resume_text(uploaded_file):
    reader = PdfReader(uploaded_file)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text[:6000]


# ---------------- Extract Basic Info Without LLM ----------------
def extract_basic_info(resume_text):

    # Extract email
    email_match = re.search(r'[\w\.-]+@[\w\.-]+', resume_text)
    email = email_match.group(0) if email_match else ""

    # Extract name (usually first line)
    lines = resume_text.split("\n")
    name = lines[0].strip() if lines else "Candidate"

    # Extract skills (basic keyword detection)
    skill_keywords = [
        "Python", "Java", "C", "C++", "SQL", "Machine Learning",
        "Data Structures", "HTML", "CSS", "JavaScript",
        "React", "Node", "Django", "Flask"
    ]

    skills_found = []
    for skill in skill_keywords:
        if skill.lower() in resume_text.lower():
            skills_found.append(skill)

    return name, email, ", ".join(skills_found[:5])


# ---------------- Call Ollama ----------------
def call_ollama(prompt, tokens=350):
    response = requests.post(
        OLLAMA_URL,
        json={
            "model": MODEL,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.3,
                "num_predict": tokens
            }
        },
        timeout=180
    )
    return response.json().get("response", "")


# ---------------- Generate Cold Email ----------------
def generate_cold_email(resume_text, job_description, company, tone):

    name, email, skills = extract_basic_info(resume_text)

    prompt = f"""
    You are a professional recruiter.

    Write a {tone.lower()} cold email.

    Candidate Name: {name}
    Candidate Email: {email}
    Key Skills: {skills}

    Target Company: {company}

    Job Description:
    {job_description[:3500]}

    Requirements:
    - 180–220 words
    - Mention relevant skills
    - Align with job role
    - Strong closing
    - Professional tone
    - Include candidate name in signature

    Return only the email.
    """

    return call_ollama(prompt)
