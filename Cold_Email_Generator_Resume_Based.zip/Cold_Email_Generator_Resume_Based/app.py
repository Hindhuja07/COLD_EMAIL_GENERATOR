
import streamlit as st
from email_engine import generate_cold_email, extract_resume_text

st.set_page_config(page_title="AI Resume-Based Cold Email Generator", page_icon="📧")
st.title("📧 AI Resume-Based Cold Email Generator")

st.write("Upload your resume and paste the job description to generate a highly personalized cold email.")

# Upload Resume
uploaded_file = st.file_uploader("Upload Resume (PDF only)", type=["pdf"])

job_description = st.text_area("Paste Job Description Here")
target_company = st.text_input("Target Company")
tone = st.selectbox("Select Tone", ["Professional", "Confident", "Friendly"])

if st.button("Generate Cold Email"):
    if not uploaded_file or not job_description or not target_company:
        st.warning("Please upload resume and fill all fields.")
    else:
        with st.spinner("Analyzing resume and generating email..."):
            resume_text = extract_resume_text(uploaded_file)
            email = generate_cold_email(
                resume_text,
                job_description,
                target_company,
                tone
            )
            st.subheader("Generated Email")
            st.code(email, language="markdown")
